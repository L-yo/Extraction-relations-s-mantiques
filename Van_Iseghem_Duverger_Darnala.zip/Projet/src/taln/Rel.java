package taln;

public class Rel {
	public String pg = "";
	public String rel = "";
	public String pd = "";
	
	public Rel(String a, String b, String c){
		pg = a;
		rel = b;
		pd = c;
	}
}
