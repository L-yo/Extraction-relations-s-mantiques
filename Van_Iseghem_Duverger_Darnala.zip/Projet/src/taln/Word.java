package taln;

import java.util.ArrayList;

public class Word {
	private ArrayList<Word> succ;
	private ArrayList<Word> pred;
	private String Word;
	private ArrayList<String> pos;
	private ArrayList<String> gender;
	private ArrayList<String> number;
	private Word Lem;
	
	public Word(String Word){
		pos = new ArrayList<String>();
		pred = new ArrayList<Word>();
		succ = new ArrayList<Word>();
		gender = new ArrayList<String>();
		number = new ArrayList<String>();
		this.setWord(Word);
		setAllInfo();
	}

	public String getWord() { return Word; }
	public void setWord(String Word) { this.Word = Word; }

	
	
	public void getAllInfo(Word Word){
		
	}
	
	public void setAllInfo(){
		
	}
	
	public ArrayList<Word> getSucc(){
		return this.succ;
	}
	
	public ArrayList<Word> getPred() { 
		return this.pred; 
	}
	
	public void setSucc(ArrayList<Word> tab){
		this.succ = tab;
	}
	
	public void setPred(ArrayList<Word> tab){
		this.pred = tab;
	}

	public ArrayList<String> getGender() {
		return gender;
	}

	public void addGender(String gender) {
		this.gender.add(gender);
	}

	public ArrayList<String> getNumber() {
		return number;
	}

	public void addNumber(String number) {
		this.number.add(number);
	}

	public ArrayList<String> getPos() {
		return pos;
	}

	public void addPos(String pos) {
		this.pos.add(pos);
	}

	public Word getLem() {
		return Lem;
	}

	public void setLem(Word lem) {
		Lem = lem;
	}
	
	public void setWordmoi(String aa){
		this.Word = aa;
	}
	
	public void setPosSpe(String string){
		this.pos.clear();
		pos.add(string);
	}
}
