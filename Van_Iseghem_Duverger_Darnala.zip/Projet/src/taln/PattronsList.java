package taln;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

public class PattronsList {
	HashMap<String, String> PList = new HashMap<String, String>();
	
	PattronsList(){
		PList = new HashMap<String, String>();
	}
	
	PattronsList(BufferedReader br) throws IOException{
		PList = new HashMap<String, String>();
		String line;
		while((line = br.readLine()) != null) {
			String[] rel = line.split("=");
			String[] pats = rel[1].split(",");
			for(String pat: pats){
				PList.put(pat, rel[0]);			
			}
		}
	}
	
	void affichage(){
		System.out.println(PList);
	}
	
	void recherche(Phrase phrase){
		for(String key: PList.keySet()){
			if(phrase.getFull().indexOf(key) > 0){
				String phraseModif = phrase.getFull().replace(" " + key + " ", " " + PList.get(key) + " ");
				String[] phraseModifSplit = phraseModif.split(" ");
				for(int i = 0; i < phraseModifSplit.length; i++){
					if(phraseModifSplit[i].contains("r_")){
						String[] keySplit = key.split(" ");
						//Word Rel = phrase.getPhra().get(i);
						String Rel = PList.get(key);
						//Recherche Sujet
						Word Sujet = phrase.getSuj();
						
						//Recherche objet
						Word Objet = null;
						//System.out.println(key + " | " + PList.get(key));
						int j = -1;
						while(j == -1 && i < phrase.getPhra().size()){
							boolean trouve = true;
							if(phrase.getPhra().get(i).getWord().equals(keySplit[0])){
								for(int l=1; l < keySplit.length; l++){
									//System.out.println(phrase.getPhra().get(i).getWord() + " | " + keySplit[l]);
									if(!phrase.getPhra().get(i+l).getWord().equals(keySplit[l])){
										trouve = false;
										break;
									}
								}
							} else {
								trouve = false;
							}
							if(trouve){
								j = i;
							} else {
								i++;
							}
						}
						int nbApostrophe = phrase.getFull().split("'").length-1;
						//int j = i + tailleKey;
						//int j = i + tailleKey + nbApostrophe;
						boolean stop = false;
						while(j < phrase.getPhra().size() && !stop && j!=-1){
							Word x = phrase.getPhra().get(j);
							if(x.getSucc().size() > 1){
								Objet = x.getSucc().get(x.getSucc().size()-1);
								stop = true;
							} else if(x.getSucc().isEmpty()){
								Objet = x;
								stop = true;
							} else if ((x.getSucc().get(0).getPos().contains("Nom") && !x.getSucc().get(0).getPos().contains("Det"))){
								Objet = x.getSucc().get(0);
								stop = true;
							} else {
								j++;
							}
						}
						if(j!=-1){
							phrase.getRecap().add(new Rel(Sujet.getWord(), " " + Rel + " ", Objet.getWord()));
						}
					}
				}
			}
		}
	}
}