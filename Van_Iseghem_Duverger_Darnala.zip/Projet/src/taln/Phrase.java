package taln;

import java.util.ArrayList;

import requeterrezo.Etat;
import requeterrezo.EtatCache;
import requeterrezo.Filtre;
import requeterrezo.Mot;
import requeterrezo.Relation;
import requeterrezo.RequeterRezo;
import requeterrezo.RequeterRezoDump;
import requeterrezo.Resultat;

public class Phrase {
	private String phraseFull = "";
	private ArrayList<Word> phrase = new ArrayList<Word>();
	private Word sujet = new Word("");
	private ArrayList<Word> pronoms = new ArrayList<Word>();
	private ArrayList<Word> noms = new ArrayList<Word>();
	private ArrayList<Rel> recap = new ArrayList<Rel>();
	static public RequeterRezo rezo;
	private Word sujgeneral;
	
	public Phrase(String phrase, String sujetGen){
		sujgeneral = new Word(sujetGen);
		phrase = clear(phrase);
		this.phraseFull = phrase;
		String[] tempo = phrase.split(" ");
		for(String str : tempo){
			if(str.contains("'")){
				String[] tempo2 = str.split("'");
				int i = 0;
				for(String str2 : tempo2){
					if(i == 0){
						this.phrase.add(new Word(str2.concat("'")));
						i++;
					}
					else{
						this.phrase.add(new Word(str2));
					}
				}
			}
			else if(str.contains(",")){
				this.phrase.add(new Word(str.replace(",", "")));
			}
			else{
				this.phrase.add(new Word(str));
			}
		}
		
		for(int i = 0; i < this.phrase.size(); i++){
			if(i == 0){
				this.phrase.get(i).getSucc().add(this.phrase.get(i+1));
			}
			else if(i == this.phrase.size() - 1){
				this.phrase.get(i).getPred().add(this.phrase.get(i-1));
			}
			else{
				this.phrase.get(i).getSucc().add(this.phrase.get(i+1));
				this.phrase.get(i).getPred().add(this.phrase.get(i-1));
			}
		}
		
		gestionTypeMot(this.phrase);
		gestionMotsComp(this.phrase);
		raffinementMots();
		gestionCara();
		
//		for(Word tmp : this.phrase){
//			System.out.println(tmp.getWord());
//			System.out.println("   " + tmp.getGender());
//			System.out.println("   " + tmp.getNumber());
//			System.out.println("   " + tmp.getPos());
//		}
		
		for(Word tmp : this.phrase){
			for(int i = 0; i < tmp.getPos().size(); i++){
				if(tmp.getPos().get(i).equals("Pro:Pers") && !tmp.getWord().equals("l'") && !tmp.getWord().equals("les") && !tmp.getWord().equals("leur")){
					this.pronoms.add(tmp);
				}
				if(tmp.getPos().get(i).equals("Nom") && tmp.getPos().size() == 1){
					this.noms.add(tmp);
				}
				
			}
		}
		
		SearchSuj();
	}
	
	/**
	 * Retire : [0],[1],etc. / espace de début de phrase / double virgules
	 * @param phraseSale
	 * La phrase de travail sale
	 * @return
	 * Une phrase de travail propre. 
	 */
	public String clear(String phraseSale){
		
		if(String.valueOf(phraseSale.charAt(0)).compareTo(" ") == 0){
			phraseSale = phraseSale.replaceFirst(" ", "");
		}

		phraseSale = phraseSale.replaceAll(",\\[.\\],", ",");
		phraseSale = phraseSale.replaceAll("’", "'");
		return phraseSale.replaceAll("\\[.\\]", "");
	}
	
	/**
	 * Assemble les mots via les expressions possibles (r_loc:11)
	 * @param phrase
	 * Phrase de travail
	 */
	public void gestionMotsComp(ArrayList<Word> phrase){
		rezo = new RequeterRezoDump();
		Resultat resultatRequete = null;
		
		for(Word word : this.phrase){
			try{
				resultatRequete = rezo.requete(word.getWord(), "r_locution", Filtre.RejeterRelationsEntrantes);
			}
			catch(Exception e) {}
			
			Etat etat = resultatRequete.getEtat();
			EtatCache etatCache = resultatRequete.getEtatCache();
			//System.out.println("L'état de la requête est : " + etat);
			//System.out.println("L'état du cache de la requête est : " + etatCache);
			
			requeterrezo.Mot tempo = resultatRequete.getMot();
			ArrayList<Relation> voisins = new ArrayList<Relation>();
			if(tempo != null) {
				voisins = tempo.getRelationsSortantesTypees("r_locution");		
				for(Relation voisin : voisins) {
					if(this.phraseFull.indexOf(voisin.getNomDestination()) != -1){
						ArrayList<Word> ret = new ArrayList<Word>();
						ret = intoPhrase(voisin.getNomDestination());
						Word tmp = new Word(voisin.getNomDestination());
						for(Word word2 : this.phrase){
							if(ret.size() > 1){
								if(word2.getWord().equals(ret.get(0).getWord()) && word2.getSucc().get(0).getWord().equals(ret.get(1).getWord())){
									if(!word2.getPred().isEmpty()){
										tmp.getPred().add(word2.getPred().get(0));
										boolean bool = false;
										for(Word tmp2 : word2.getPred().get(0).getSucc()){
											if(tmp2.getWord().equals(tmp.getWord())){
												bool = true;
												break;
											}
										}
										if(!bool){
											word2.getPred().get(0).getSucc().add(tmp);
										}
									}
								}
							}
							else{
								if(word2.getWord().equals(ret.get(0).getWord())){
									if(!word2.getPred().isEmpty()){
										tmp.getPred().add(word2.getPred().get(0));
										boolean bool = false;
										for(Word tmp2 : word2.getPred().get(0).getSucc()){
											if(tmp2.getWord().equals(tmp.getWord())){
												bool = true;
												break;
											}
										}
										if(!bool){
											word2.getPred().get(0).getSucc().add(tmp);
										}
									}
								}
							}
						}
						
						for(Word word2 : this.phrase){
							if(word2.getWord().equals(ret.get(ret.size()-1).getWord())){
								if(!word2.getSucc().isEmpty()){
									tmp.getSucc().add(word2.getSucc().get(0));
									
									boolean bool = false;
									for(Word tmp2 : word2.getSucc().get(0).getPred()){
										if(tmp2.getWord().equals(tmp.getWord())){
											bool = true;
											break;
										}
									}
									if(!bool){
										word2.getSucc().get(0).getPred().add(tmp);
									}
								}
							}
						}
					}
				}
			}
		}
	}
	public boolean compNumber(Word w1, Word w2){
		
		if(w1.getNumber().size() == w2.getNumber().size() && w1.getNumber().size() == 2){
			return true;
		}
		else if(w1.getNumber().size() == w2.getNumber().size() && w1.getNumber().size() == 1){
			return w1.getNumber().get(0).equals(w2.getNumber().get(0));
		}
		else if(w1.getNumber().size() == 2 && w2.getNumber().size() == 1){
			return true;
		}
		else if(w1.getNumber().size() == 1 && w2.getNumber().size() == 2){
			return true;
		}
		else{
			return false;
		}
		
	}
	public boolean compGender(Word w1, Word w2){
		if(w1.getGender().size() == w2.getGender().size() && w1.getGender().size() == 2){
			return true;
		}
		else if(w1.getGender().size() == w2.getGender().size() && w1.getGender().size() == 1){
			return w1.getGender().get(0).equals(w2.getGender().get(0));
		}
		else if(w1.getGender().size() == 2 && w2.getGender().size() == 1){
			return true;
		}
		else if(w1.getGender().size() == 1 && w2.getGender().size() == 2){
			return true;
		}
		else{
			return false;
		}
		
	}
	public boolean compNG(Word w1, Word w2){
		return compNumber(w1, w2) && compGender(w1, w2);
		
	}
	
	public ArrayList<Word> getPro(){
		return this.pronoms;
	}
	public ArrayList<Word> getNom(){
		return this.noms;
	}
	public ArrayList<Word> getPhra(){
		return this.phrase;
	}
	public String getFull(){
		return this.phraseFull;
	}
	public void SearchSuj(){
		int ind_vb = 0;
		boolean suj_trouve = false;
		boolean vb_trouve = false;
		for(int i = 0; i < this.phrase.size(); i++){
				if(this.phrase.get(i).getPos().contains("Ver") && this.phrase.get(i).getPos().contains("VerbalTime") && !vb_trouve){
					ind_vb=i;
					vb_trouve = true;
					if(!suj_trouve){
						if(i > 0){
							for(int ind_pro = 0; ind_pro < this.pronoms.size(); ind_pro++){
								if(this.phrase.get(i-1).getWord().equals(this.pronoms.get(ind_pro).getWord())){
									this.sujet = this.phrase.get(i-1);
									suj_trouve = true;
								}
							}
						}
						for(int x = 0; x < ind_vb; x++){
							for(int ind_nom = 0; ind_nom < this.noms.size(); ind_nom++){
								
								if(this.phrase.get(x).getWord().equals(this.noms.get(ind_nom).getWord()) && this.compNumber(this.phrase.get(x), this.noms.get(ind_nom)) && !suj_trouve){
									this.sujet = this.noms.get(ind_nom);
									suj_trouve = true;
								}
							}
						}
					}					
				}
		}
		if(!suj_trouve){
			this.sujet = sujgeneral;
		}
	}
	
	public Word getSuj(){
		return this.sujet;
	}
	
	public ArrayList<Word> intoPhrase(String phrase){
		ArrayList<Word> ret = new ArrayList<Word>();
		
		String[] tempo = phrase.split(" ");
		for(String str : tempo){
			if(str.contains("'")){
				String[] tempo2 = str.split("'");
				int i = 0;
				for(String str2 : tempo2){
					if(i == 0){
						ret.add(new Word(str2.concat("'")));
						i++;
					}
					else{
						ret.add(new Word(str2));
					}
				}
			}
			else{
				ret.add(new Word(str));
			}
		}
		
		return ret;
	}
	
	public String toString(){
		String str = "\n Phrase brut : " + this.phraseFull + "\n Pronoms : ";
		if(this.pronoms.size() > 0){
			str += this.pronoms.get(0).getWord();
			for(int i = 1; i  < this.pronoms.size(); i++){
				str += " | " + this.pronoms.get(i).getWord();
			}
		}
		str += "\n Noms : ";
		if(this.noms.size() > 0){
			str += this.noms.get(0).getWord();
			for(int i = 1; i  < this.noms.size(); i++){
				str += " | " + this.noms.get(i).getWord();
			}
		}
		

		return str;
	}
	
	
	public void gestionTypeMot(ArrayList<Word> phrase){
		rezo = new RequeterRezoDump();
		Resultat resultatRequete = null;
		
		for(Word word : this.phrase){
			try{
				resultatRequete = rezo.requete(word.getWord(), "r_pos", Filtre.RejeterRelationsEntrantes);
			}
			catch(Exception e) {}
			
			Etat etat = resultatRequete.getEtat();
			EtatCache etatCache = resultatRequete.getEtatCache();
			//System.out.println("L'état de la requête est : " + etat);
			//System.out.println("L'état du cache de la requête est : " + etatCache);
			
			requeterrezo.Mot tempo = resultatRequete.getMot();
			ArrayList<Relation> voisins = new ArrayList<Relation>();
			if(tempo != null) {
				voisins = tempo.getRelationsSortantesTypees("r_pos");		
				for(Relation voisin : voisins) {
					if(voisin.getPoids() > 0){
						String[] voisinSplit = voisin.getMotFormateDestination().split(":");
						
						if(voisinSplit[0].equals("Gender")){
							if(!word.getGender().contains(voisinSplit[1])){
								word.addGender(voisinSplit[1]);
							}
						}
						else if(voisinSplit[0].equals("Number")){
							if(!word.getNumber().contains(voisinSplit[1])){
								word.addNumber(voisinSplit[1]);
							}
						}
						else if(voisin.getMotFormateDestination().equals("Pro:Pers")){
							if(!word.getPos().contains(voisin.getMotFormateDestination())){
								word.addPos(voisin.getMotFormateDestination());
							}
						}
						else{
							if(!word.getPos().contains(voisinSplit[0])){
								word.addPos(voisinSplit[0]);
							}
							
							if(voisinSplit.length > 1 && voisinSplit[0].equals("Ver")){
								/*if(voisinSplit[1].contains("Fem")){
									if(!word.getGender().contains("Fem")){
										word.addGender("Fem");
									}
								}
								if(voisinSplit[1].contains("Mas")){
									if(!word.getGender().contains("Mas")){
										word.addGender("Mas");
									}
								}*/
								if(voisinSplit[1].contains("SG")){
									if(!word.getNumber().contains("Sing")){
										word.addNumber("Sing");
									}
								}
								if(voisinSplit[1].contains("PL")){
									if(!word.getNumber().contains("Plur")){
										word.addNumber("Plur");
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	public void raffinementMots(){
		for(Word word : this.phrase){
			if(word.getPos().contains("Nom")){
				if(!word.getPred().isEmpty()){
					if(word.getPred().get(0).getPos().contains("Det") && !word.getPos().contains("Det")){
						word.getPred().get(0).setPosSpe("Det");
						word.setPosSpe("Nom");
					}
				}
			}
			
			if(word.getPos().contains("Adj") && word.getPos().size() == 1){
				if(!word.getPred().isEmpty() && !word.getSucc().isEmpty()){
					if(word.getPred().get(0).getPos().contains("Det") && word.getSucc().get(0).getPos().contains("Nom")){
						word.getPred().get(0).setPosSpe("Det");
						word.getSucc().get(0).setPosSpe("Nom");
						word.setPosSpe("Adj");
					}
				}
			}
			
			if(word.getPos().contains("Nom")){
				if(!word.getPred().isEmpty() && !word.getSucc().isEmpty()){
					if(word.getPred().get(0).getPos().contains("Det") && word.getSucc().get(0).getPos().contains("Adj") 
							&& !word.getSucc().get(0).getPos().contains("Ver") && !word.getPos().contains("Det")){
						word.getPred().get(0).setPosSpe("Det");
						word.getSucc().get(0).setPosSpe("Adj");
						word.setPosSpe("Nom");
					}
				}
			}
			
			if(word.getPos().contains("Ver")){
				if(!word.getPred().isEmpty()){
					if(word.getPred().get(0).getPos().contains("Pre")){
						word.getPos().remove("Ver");
					}
				}
			}
			
			
		}
	}
	
	public void gestionCara(){
		for(Word word : this.phrase){
			if(word.getPos().contains("Nom") && word.getPos().size() == 1){
				if(!word.getPred().isEmpty()){
					if(word.getPred().get(0).getPos().contains("Adj") && word.getPred().get(0).getPos().size() == 1){
						recap.add(new Rel(word.getPred().get(0).getWord(), " r_carac ", word.getWord()));
					}
				}
					
				if(!word.getSucc().isEmpty()){
					if(word.getSucc().get(0).getPos().contains("Adj") && word.getSucc().get(0).getPos().size() == 1){
						recap.add(new Rel(word.getSucc().get(0).getWord(), " r_carac ", word.getWord()));
					}
				}
			}
		}
	}

	public ArrayList<Rel> getRecap() {
		return recap;
	}

	public void setRecap(ArrayList<Rel> recap) {
		this.recap = recap;
	}
	
}
