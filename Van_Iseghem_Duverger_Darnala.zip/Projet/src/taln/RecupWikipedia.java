package taln;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.*;
import org.jsoup.nodes.*;

import requeterrezo.Filtre;
import requeterrezo.Mot;
import requeterrezo.Relation;
import requeterrezo.RequeterRezo;
import requeterrezo.RequeterRezoDump;
import requeterrezo.Resultat;

public class RecupWikipedia {
	static public RequeterRezo rezo;
	
	public RecupWikipedia(String mot) throws IOException{
		rezo = new RequeterRezoDump();
		Resultat resultatRequete = null;
		
		ecritureFichier(mot);
		
		try{
			resultatRequete = rezo.requete(mot, "r_associated", Filtre.RejeterRelationsEntrantes);
		}
		catch(Exception e) {}
		
		Mot tempo = resultatRequete.getMot();
		ArrayList<String> typesRed = new ArrayList<String>();
		
		if(mot != null) {
			ArrayList<Relation> types = tempo.getRelationsSortantesTypees("r_associated");
			
			for(Relation type : types) {
				String typeReduit = type.toString().split(":")[0];
				if (!typesRed.contains(typeReduit)) {
					if(!type.getDestination().getNom().contains(">")){
						String motFinal = type.getDestination().getNom().replace(" ", "_");
						ecritureFichier(motFinal);
					}
				}
					
			}
		}
	}
			
	public void ecritureFichier(String mot) throws IOException{
		
		Document doc = null;
		try{
			doc = Jsoup.connect("https://fr.wikipedia.org/wiki/" + mot).get();
		}catch(Exception e){}
		
		if(doc != null){
			Element body = doc.body();
			for( Element element : body.getElementsByTag("p") )
			{
				try (BufferedWriter bw = new BufferedWriter(new FileWriter("./MotsWiki/" + mot + ".txt", true))) {
	
			            bw.append(element.text() + "\n");
	
			        } catch (IOException e) {
			            System.err.format("IOException: %s%n", e);
			        }
				break;
			}
		}
	}
}
