package taln;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

import org.jsoup.*;
import org.jsoup.nodes.*;

import requeterrezo.Filtre;
import requeterrezo.Mot;
import requeterrezo.RequeterRezo;
import requeterrezo.RequeterRezoDump;
import requeterrezo.Resultat;

public class main {
	
	static public RequeterRezo rezo;
	static public Phrases phrases;

	public static void main(String[] args) throws MalformedURLException, IOException {
		
		phrases = new Phrases();
		
		//Récupération de mots via wikipedia
		//RecupWikipedia test = new RecupWikipedia("astronomie");
		
		//Création des phrases
		
		try(BufferedReader br2 = Files.newBufferedReader(Paths.get("patrons.txt"))){
			PattronsList PL = new PattronsList(br2);
			
			String sujetGen = "astronomie";
			
			BufferedReader br = new BufferedReader(new FileReader("./MotsWiki/" + sujetGen + ".txt"));
			
			System.out.println("Prétraitement");
			String phraseLue = br.readLine();
			phraseLue = phraseLue.toLowerCase();
			phraseLue = phraseLue.replace("(", "");
			phraseLue = phraseLue.replace(")", "");
			while(phraseLue != null){
				if(phraseLue.contains(".")){
					String[] tempo = phraseLue.split("\\.");
					for(String str : tempo){
						phrases.add(new Phrase(str, sujetGen));
					}
					phraseLue = br.readLine();
				}
				else{
					phrases.add(new Phrase(phraseLue, sujetGen));
					phraseLue = br.readLine();
				}
			}
			System.out.println("Prétraitement terminé\n");
			
			System.out.println("Recherche de relations...");
			phrases.gestionAssociated();
			phrases.coRef();
			for(Phrase phrase : phrases.getPhrases()){
				PL.recherche(phrase);
			}
			System.out.println("Recherche de relations terminée\n");
		
		
		
			for(Phrase phrase : phrases.getPhrases()){
				System.out.println("Phrase Complète : [" + phrase.getFull() + "]");
				System.out.println("Sujet : " + phrase.getSuj().getWord() + " \n");
				System.out.println("Relations : ");
				for(Rel rel : phrase.getRecap()){
					System.out.println("   " + rel.pg + " " + rel.rel + " " + rel.pd);
				}
				
				System.out.println("===================================\n");
			}
		}
	}
}
