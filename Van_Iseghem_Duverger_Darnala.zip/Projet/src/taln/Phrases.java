package taln;

import java.util.ArrayList;

import requeterrezo.Etat;
import requeterrezo.EtatCache;
import requeterrezo.Filtre;
import requeterrezo.Relation;
import requeterrezo.RequeterRezo;
import requeterrezo.RequeterRezoDump;
import requeterrezo.Resultat;

public class Phrases {
	
	private ArrayList<Phrase> phrases = new ArrayList<Phrase>();
	static public RequeterRezo rezo;
	
	public void add(Phrase phrase){
		phrases.add(phrase);
	}
	
	public ArrayList<Phrase> getPhrases(){
		return this.phrases;
	}
	public void coRef(){
		ArrayList<Word> coref = new ArrayList<Word>();
		for(int i = 0; i < this.phrases.size(); i++){
			for(int ind_pro = 0; ind_pro < this.phrases.get(i).getPro().size(); ind_pro++){

				if(this.phrases.get(i).getPro().get(ind_pro).getWord().equals(this.phrases.get(i).getPhra().get(0).getWord()) && i > 0){
					//Cas où le pronom est en début de phrase : recherche dans la phrase d'avant
//					coref.add(this.phrases.get(i).getPro().get(ind_pro));
//					coref.add(this.phrases.get(i-1).getSuj());
					this.phrases.get(i).getPhra().get(0).setWord("(" + this.phrases.get(i-1).getSuj().getWord() + ")");
				}
				else{
					for(int ind_mot = 0; ind_mot < this.phrases.get(i).getPhra().size(); ind_mot++){
						if(this.phrases.get(i).getPhra().get(ind_mot).getWord().equals(this.phrases.get(i).getPro().get(ind_pro).getWord())){
							for(int cpt = ind_mot; cpt >= 0; cpt--){
								for(int cpt2 = 0; cpt2 < this.phrases.get(i).getNom().size(); cpt2++){
									if(this.phrases.get(i).getPhra().get(cpt).getWord().equals(this.phrases.get(i).getNom().get(cpt2).getWord())){
										this.phrases.get(i).getPhra().get(ind_mot).setWord("("+this.phrases.get(i).getNom().get(cpt2).getWord() + ")");
//										coref.add(this.phrases.get(i).getPro().get(ind_pro));
//										coref.add(this.phrases.get(i).getNom().get(cpt2));
										
									}
								}
							}
						}
					}
				}
			}
			
		}
	}
	
	public void gestionAssociated(){
		rezo = new RequeterRezoDump();
		Resultat resultatRequete = null;
		for(Phrase phrase : this.phrases){
			try{
				resultatRequete = rezo.requete(phrase.getSuj().getWord(), "r_associated", Filtre.RejeterRelationsEntrantes);
			}
			catch(Exception e) {}
			
			Etat etat = resultatRequete.getEtat();
			EtatCache etatCache = resultatRequete.getEtatCache();
			//System.out.println("L'état de la requête est : " + etat);
			//System.out.println("L'état du cache de la requête est : " + etatCache);
			
			requeterrezo.Mot tempo = resultatRequete.getMot();
			ArrayList<Relation> voisins = new ArrayList<Relation>();
			if(tempo != null) {
				voisins = tempo.getRelationsSortantesTypees("r_associated");
				int i = 0;
				for(Relation voisin : voisins) {
					if(i < 10){
						for(Word word : phrase.getNom()){
							if(word.getWord().equals(voisin.getMotFormateDestination())){
								phrase.getRecap().add(new Rel(phrase.getSuj().getWord(), " r_associated ", word.getWord()));
							}
						}
					}
					else{
						break;
					}
				}
			}
		}
	}

	
	public String toString(){
		String str = "";
		
		for(int i = 0; i < this.phrases.size(); i++){
//			this.phrases.get(i).SearchSuj();
//			str += "Phrase "+ (i+1) + " : \t Sujet : "+ this.phrases.get(i).getSuj().getWord();
			str += this.phrases.get(i) + "\n";	
		}
		return str;
	}
}
